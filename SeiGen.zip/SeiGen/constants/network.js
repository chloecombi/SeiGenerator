const NETWORK = {
  eth: "eth",
  sol: "sol",
  sei: "sei",
};

module.exports = {
  NETWORK,
};
